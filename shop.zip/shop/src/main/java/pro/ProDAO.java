package pro;

import common.DBConnPool;

public class ProDAO extends DBConnPool{

	private static ProDAO pdao = new ProDAO();
	
	public static ProDAO getPdao() {
		return pdao;
	}
	
	private ProDAO() {
		super();
	}
	
	//insert 
	
	//delete
	
	//update
	
	//select
	
	
	
}
